from argparse import ArgumentParser
import data_correction.vct_lib.utils.env_setup.set_paths as sp
import data_correction.vct_lib.run_data_correction as rdc


if __name__ == "__main__":
    # Initialize the argument parser
    parser = ArgumentParser()
    # Add a positional argument for the environment
    parser.add_argument('--env', nargs='?', help="Defines the runtime environment of the program",
                        const=1, type=str, default="prod")

    # Add a positional argument for the file type
    parser.add_argument('--file_type', nargs='?', help="Defines the output as csv/parquet",
                        const=1, type=str, default="parquet")

    # Add a positional argument for the file type
    parser.add_argument('--program_prefix', nargs='?', help="Defines the program_prefix",
                        const=1, type=str, default="data_correction")

    # Parse the command-line arguments
    args = parser.parse_args()

    # Run the main process using the specified environment
    localPaths = sp.identifyLocalPaths(args.env.upper(), args.program_prefix)

    rdc.main(localPaths)

