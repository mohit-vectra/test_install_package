import os


def tool(tool_name, output_dir_json, file_path):
    folders = output_dir_json["FOLDERS"]
    paths = []

    for folderName in folders:
        folderPath = os.path.join(file_path, folderName)
        toolDir = os.path.join(folderPath, tool_name)

        if not os.path.exists(toolDir):
            # TODO: Log instead of print
            print(f"{toolDir} does not exist, creating it...")
            os.makedirs(toolDir)

        else:
            # TODO: Log instead of print
            print(f"{toolDir} already exists")

        paths.append(toolDir)
    return paths


def parts():
    ...
