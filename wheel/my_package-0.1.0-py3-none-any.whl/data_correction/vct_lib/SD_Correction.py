import numpy as np

# Todo: Should we keep this in its own module and all classes can inherit?
# with open(r'C:\Users\admin\Desktop\Vectra Tasks\Python or Scripting Tasks\Python dev workspace\correction program\correctionModule (1)\correctionModule\src\input\psd\new\issue_report.json', 'r') as jsonFile:
#     issueDict = json.load(jsonFile)


class Correction_FaceVec:
    def __init__(self, issue_dict, dataFrame_FV, issues_FV):
        self.dfFaceVec = dataFrame_FV
        self.sheet_name = 'FaceVec'
        self.columns = dataFrame_FV.columns
        self.allErrors_FV = issue_dict['FaceVec']['Errors']
        self.allExceptions_FV = issue_dict['FaceVec']['Exceptions']
        self.issuesToCorrect = issues_FV
        # Get the index of the required columns from the column header in the dataframe
        # self.colIdx_PreFab = self.columns.get_loc('Pre-Fab')
        # self.colIdx_FaceType = self.columns.get_loc('Face Type')
        # self.colIdx_HoleSize = self.columns.get_loc('HOLE_SIZE')
        # self.colIdx_FeatName = self.columns.get_loc('Feat Name')
        # self.colIdx_Radius = self.columns.get_loc('Radius')

    def correctFeatName_HoleSize(self):
        # This can do the correction without reading the json at all

        # Create a boolean mask indicating 'Y' in 'Pre-Fab' Column
        isPreFabCol_Y = (self.dfFaceVec['Pre-Fab'] == 'Y').to_numpy()
        # Create a boolean mask indicating 'CYLINDRICAL' in 'Face Type' Column
        isFaceType_Cylindrical = (self.dfFaceVec['Face Type'] == 'Cylindrical'.upper()).to_numpy()

        requiredCondition = np.logical_and(isPreFabCol_Y, isFaceType_Cylindrical)

        # Update the 'HOLE_SIZE' column with DIA XX at the rows having Pre_Fab = 'Y' and Face Type = 'CYLINDRICAL'
        self.dfFaceVec['HOLE_SIZE'] = np.where(requiredCondition,
                                               f"DIA {2 * (self.dfFaceVec['Radius'])}",
                                               self.dfFaceVec['HOLE_SIZE'])
        # Update the 'Feat Name' column with 'CLR' at the rows having Pre_Fab = 'Y' and Face Type = 'CYLINDRICAL'
        self.dfFaceVec['Feat Name'] = np.where(requiredCondition,
                                               'CLR', self.dfFaceVec['Feat Name'])


class Correction_BodyName:

    def __init__(self, issue_dict, issues_BN, dataFrame_BN):
        self.issues_BN = issues_BN
        self.dataFrame_BN = dataFrame_BN
        self.columns = dataFrame_BN.columns
        self.sheet_name = 'BodyName'
        self.allErrors_BodyName = issue_dict[self.sheet_name]['Errors']
        self.allExceptions_BodyName = issue_dict[self.sheet_name]['Exceptions']
        # Get the index of the required columns from the column header in the dataframe
        self.colIdx_stockSize = self.columns.get_loc('STOCK_SIZE')

    def correct_Shape(self):
        # Replace all blank cells in the column 'SHAPE' with the value 'FLAT'
        self.dataFrame_BN.fillna({'SHAPE': 'FLAT'}, inplace=True)

    def correct_component(self):
        # Get the value of the first non-null component name in the column 'Component Name'
        firstNonNullComponent_Idx = self.dataFrame_BN['Component Name'].first_valid_index()
        firstNonNullComponent = self.dataFrame_BN['Component Name'].iloc[firstNonNullComponent_Idx]
        # Assign the first non-null value to all missing values in the 'Component Name' column
        self.dataFrame_BN.fillna({'Component Name': firstNonNullComponent}, inplace=True)

    def correct_stockSize(self):
        isBoundingBoxPresent = ~(
            self.dataFrame_BN[['Magnitude X', 'Magnitude Y', 'Magnitude Z']].isnull().any(axis=1)).to_numpy()
        isStockSizeEmpty = self.dataFrame_BN.iloc[:, self.colIdx_stockSize].isnull().to_numpy()
        # Join the Magnitude X,Y,Z with '  mm X '
        reqdCondition = np.logical_and(isStockSizeEmpty, isBoundingBoxPresent)
        self.dataFrame_BN.iloc[:, self.colIdx_stockSize] = np.where(reqdCondition,
                                                                    (self.dataFrame_BN[['Magnitude X',
                                                                                        'Magnitude Y',
                                                                                        'Magnitude Z']].astype(str)
                                                                     .apply(" mm X ".join, axis=1)),
                                                                    self.dataFrame_BN.iloc[:, self.colIdx_stockSize])
        # Append the joined values with ' mm'
        self.dataFrame_BN.iloc[:, self.colIdx_stockSize] = np.where(reqdCondition,
                                                                    self.dataFrame_BN.iloc
                                                                    [:, self.colIdx_stockSize] + ' mm',
                                                                    self.dataFrame_BN.iloc[:, self.colIdx_stockSize])


class Correction_MiscInfo:
    pass
