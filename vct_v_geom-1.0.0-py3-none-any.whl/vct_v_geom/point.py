import numpy as np
from vct_v_geom.vector import directionVector, dotProduct


def pointEquality(point1: np.ndarray, point2: np.ndarray):
    """
    Returns the boolean mask of equality between vertex1 and vertex2
    If the shapes are same, returns equality with corresponding vertex of vertex1 with vertex2
    If one of them is just a single vertex, returns mask indicating equality with all vertices from the other array.
    :param point1:numpy array of shape (n,3) or (n,2)
    :param point2: numpy array of shape (n,3) or (n,2)
    :return: boolean mask of equality between vertex1 and vertex2
    """
    # Check if vertex1 is equal to vertex2
    numRowsVertex2 = point2.shape[0]
    if numRowsVertex2 <= 1:
        difference = np.abs(point1 - point2)
        return np.all(difference < 0.1)

    # check if vertex1 is present in any of the arrays of vertex2
    differences = np.abs(point1 - point2)
    tolerCheck = np.all(differences < 0.1, axis=1)

    # check if two arrays are of same shape and identical.
    if point1.shape == point2.shape:
        return tolerCheck
    return np.any(tolerCheck)


def pointAtDistance(startPoint: np.ndarray, distance: np.ndarray, directionUnitVector: np.ndarray):
    """
    Determines the co-ordinates of the point at the desired distance.
    Args:
        startPoint: Numpy array of shape (n,3)
        distance: Numpy array of shape (n,1)
        directionUnitVector: Numpy array of shape (n,3)
    Returns:
        Numpy array having co-ordinates at desired distance.

    """
    point = startPoint + (distance*directionUnitVector)
    return point


def projectedDistance_TwoPoints(point1: np.ndarray, point2: np.ndarray, directionVec: np.ndarray):
    """
    Computes the projected distance between the direction vector of the given points and the given direction vector
    :param point1: A numpy array of shape (n,3)
    :param point2: A numpy array of shape (n,3)
    :param directionVec: A numpy array of shape (n,3)
    :return: A numpy array of shape (n,1)
    """
    distVector = directionVector(point1, point2)
    dotProd = dotProduct(distVector, directionVec)
    return np.abs(dotProd)

# todo: tests to be written for following functions.
