def addMissingColumns(data, missingColumns):

    for workSheetName, missingColumnNames in missingColumns.items():
        try:
            dataFrame = data[workSheetName]
            for missingColumnName in missingColumnNames:
                if missingColumnName not in dataFrame.columns:
                    dataFrame[missingColumnName] = [None] * len(dataFrame)

            data[workSheetName] = dataFrame
        except KeyError:
            pass

    return data


def correctCaseAndDelimiters(data, case, delimiter):
    newData = {}
    for workSheetName, df in data.items():
        if case == 'lower':
            df.columns = (df.columns.str.strip()).str.lower()
            workSheetName = (workSheetName.strip()).lower()
        else:
            df.columns = (df.columns.str.strip()).str.upper()
            workSheetName = (workSheetName.strip()).upper()

        # Change column names of the form "Edge Vertex-x" to "edge_vertex_x".
        df.columns = (df.columns.str.replace(" ", delimiter)).str.replace("-", delimiter)
        workSheetName = (workSheetName.replace(" ", delimiter)).replace("-", delimiter)
        newData[workSheetName] = df

    return newData


def castColumnsToDataTypes(data, dataTypeDict):
    for worksheetName, df in data.items():
        data[worksheetName] = df.astype(dataTypeDict[worksheetName])

    return data


def normalizeDataFrames(data, requiredColumns):
    workSheetToNormalizedTablesMapping = {'facevec': ['f_identifiers', 'f_vec', 'f_attrib', 'f_alt']}
    normalizedData = {}
    for workSheetName, workSheetData in data.items():

        if workSheetName in workSheetToNormalizedTablesMapping:
            normalizedTablesList = workSheetToNormalizedTablesMapping[workSheetName]

            for table in normalizedTablesList:
                normalizedData[table] = workSheetData.loc[:, requiredColumns[table]]
        else:
            normalizedData[workSheetName] = workSheetData.loc[:, requiredColumns[workSheetName]]

    return normalizedData
