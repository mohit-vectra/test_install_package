from vct_v_geom.vector import *
from typing import Literal, Optional

ANGLE_TOLERANCE_1_DEG_PRL = 0.0001523
TOLERANCE = 0.1


def getUnitizedMatrix(matrix: np.ndarray):
    """
    Returns a unitized matrix
    :param matrix: numpy array
    :return: unitized matrix
    """
    unitized_matrix = matrix / np.linalg.norm(matrix, axis=1, keepdims=True)
    return unitized_matrix


def rowMatrix(matrix: np.ndarray):
    """
    Returns a row matrix
    :param matrix: numpy array
    :return: row matrix
    """
    vector = matrix.reshape(1, -1)
    return vector


def orthographicProjection(matrix1, matrix2):
    """
    Determines if matrix2 is an orthographic projection of matrix1
    Key:
    h1, v1, n1 -> hAxis, vAxis, nAxis of matrix 1 respectively
    h2, v2, n2 -> hAxis, vAxis, nAxis of matrix 2 respectively
    Resultant matrix will be of the form [[(dot-product of h1, h2), (dot-product of h1, v2), (dot-product of h1, n2)],
                                          [(dot-product of v1, h2), (dot-product of v1, v2), (dot-product of v1, n2)],
                                          [(dot-product of n1, h2), (dot-product of n1, v2), (dot-product of n1, n2)]

    """
    dotProductMatrix = np.matmul(matrix1, matrix2.transpose())

    # Get the absolute value of all the elements in the matrix.
    absDotProductMatrix = np.abs(dotProductMatrix)

    # Get a matrix of booleans, where the element value is True if the vectors are orthogonal to each other.
    orthogonalMatrix = absDotProductMatrix < ANGLE_TOLERANCE_1_DEG_PRL

    # Create a matrix of ones.
    onesMatrix = np.ones(shape=(3, 3))
    # Get a matrix of booleans, where the element value is True if the vectors are in the same direction.
    sameDirectionMatrix = np.abs(absDotProductMatrix - onesMatrix) < ANGLE_TOLERANCE_1_DEG_PRL

    # Perform a logical OR operation between the elements of orthogonal and sameDirection matrices.
    truthArray = np.logical_or(orthogonalMatrix, sameDirectionMatrix)

    # Return true if the resultant matrix contains only True booleans.
    return truthArray.all()


def isAlignedWithView(vector: np.ndarray, rotationMatrix: np.ndarray):
    """
    Checks if given vector is aligned to the given view
    :param vector: Numpy array of shape (n,3)
    :param rotationMatrix: Numpy array of shape (n,3,3)
    :return: Boolean value indicating the alignment of the vector with the view
    """
    alignedDirections = alignedDirectionToView(vector=vector, rotationMatrix=rotationMatrix)
    alignedCheck = np.where(np.isin(np.char.lower(alignedDirections.astype(str)), ['x', 'y', 'z']),
                            True, False)
    return alignedCheck


def alignedDirectionToView(vector: np.ndarray, rotationMatrix: np.ndarray):
    """
    Returns the direction to which the vector is aligned with the view
    :param vector: Numpy array of shape (n, 3)
    :param rotationMatrix: Numpy array of shape (n, 3, 3)
    :return: Numpy array of shape (n, ) containing the directions to which the vector is aligned with the view
    """
    rotationMatrix_Haxis = rotationMatrix[:, 0, :]
    rotationMatrix_Vaxis = rotationMatrix[:, 1, :]
    rotationMatrix_Naxis = rotationMatrix[:, 2, :]
    alignedX = isAligned(vector, rotationMatrix_Haxis)
    alignedY = isAligned(vector, rotationMatrix_Vaxis)
    alignedZ = isAligned(vector, rotationMatrix_Naxis)

    conditions = [alignedX, alignedY, alignedZ]
    values = ['x', 'y', 'z']
    alignedDirections = np.select(conditions, values, default=None)
    return alignedDirections


def directionComponent(vector1, rotationMatrix):
    hComp = rotationMatrix[:, 0, :]
    vComp = rotationMatrix[:, 1, :]
    zComp = rotationMatrix[:, 2, :]
    """
    # rotationMatrix shape: (3,3,3) or (n,3,3)?
    # Let vector1 be (n,3) i.e. n,3 dim vectors in space -> Test it in this direction once
    # 7 (3,3) -> (7,3,3)
    
    # test case for (1, 3) with (n, 3):
    vec = np.array([1, 0, 0]).reshape(-1, 3)
    rotMat = np.array([1, 0, 0, 0, 1, 0, 0, 0, 1]*4).reshape(4, 3, 3)
    res = directionComponent_Modified(vec, rotMat)
    print(res)
    
    test case for (n,3) with (m,3,3) where n = m: 
    vec = np.array([1, 0, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9]).reshape(-1, 3)  # This is 4,3 i.e, 4 vectors in 3D
    rotMat = np.array([1, 0, 0, 0, 1, 0, 0, 0, 1] * 4).reshape(4, 3, 3)  # This is 4 views in 3D
    res = directionComponent_Modified(vec, rotMat)
    print(res)
    """

    sameDirection_X = isSameDirection(vector1, hComp)
    sameDirection_Y = isSameDirection(vector1, vComp)
    sameDirection_Z = isSameDirection(vector1, zComp)

    conditions = [sameDirection_X, sameDirection_Y, sameDirection_Z]
    choices = ['x', 'y', 'z']

    directionComponents = np.select(conditions, choices, default=None)

    return directionComponents


def getIdentityMatrix(numOfRows: int):
    """
    Returns identity matrix of shape (numOfRows, numOfRows)
    :param numOfRows: number of rows required in the matrix
    :return: identity matrix
    """
    return np.eye(numOfRows, dtype='float')


def rotate(rotationMatrix: np.ndarray, entity: np.ndarray, reshape=False):
    """
    Rotates the given entity as per rotation matrix.
    Args:
        rotationMatrix: Numpy array of shape (n,3,3).
        entity: Numpy array of shape (n,3)
        reshape: A boolean value to indicate whether reshaping needs to be done (By default, it is false).
    Returns:
        Rotated entity.
    """
    if reshape:
        shape = len(entity)
        entity = np.matrix(np.reshape(entity, (shape, 3)), dtype='float')

    # Multiply matrix with vector and return the output
    if len(np.shape(rotationMatrix)) < 3:
        rotatedEntity = np.matmul(entity, rotationMatrix)
    else:
        rotatedEntity = np.einsum('ij,ijk->ik', entity, rotationMatrix)

    if isinstance(rotatedEntity, np.matrix):
        shape = np.shape(rotatedEntity)[0]
        rotatedEntity = np.reshape(np.array(rotatedEntity), (shape, 3))

    return rotatedEntity


def closestAxisOfView(vector: np.ndarray, rotationMatrix: np.ndarray):
    """
    Determines the closest axis of view.
    Args:
        vector: Numpy array of shape n,3
        rotationMatrix: Numpy array of shape n,3,3
    Returns: Closest axis of view (angle in radians).

    """
    angleTolerance = 45.0
    # Create arrays with H,V,N axes of rotationMatrix
    rotationMatrix_Haxis = rotationMatrix[:, 0, :]
    rotationMatrix_Vaxis = rotationMatrix[:, 1, :]
    rotationMatrix_Naxis = rotationMatrix[:, 2, :]
    # Compute included angle between given vector and H,V,N axis of the given rotation matrix.
    # angle_Vector_Haxis = includedAngle(vector, rotationMatrix_Haxis)
    angle_Vector_Haxis = includedAngle(vector, rotationMatrix_Haxis).reshape(-1, 1)
    # angle_Vector_Vaxis = includedAngle(vector, rotationMatrix_Vaxis)
    angle_Vector_Vaxis = includedAngle(vector, rotationMatrix_Vaxis).reshape(-1, 1)
    # angle_Vector_Naxis = includedAngle(vector, rotationMatrix_Naxis)
    angle_Vector_Naxis = includedAngle(vector, rotationMatrix_Naxis).reshape(-1, 1)
    # Create a template array to store the axis along which, closest view is present.
    closestAxisOfView_TemplateArray = np.full(shape=(len(vector), 1), fill_value=np.nan, dtype=float)

    isAngle_HaxisVector_LessThanAll = np.logical_and(angle_Vector_Haxis <= angle_Vector_Vaxis,
                                                     angle_Vector_Haxis <= angle_Vector_Naxis,
                                                     angle_Vector_Haxis <= angleTolerance)
    isAngle_VaxisVector_LessThanAll = np.logical_and(angle_Vector_Vaxis <= angle_Vector_Haxis,
                                                     angle_Vector_Vaxis <= angle_Vector_Naxis,
                                                     angle_Vector_Vaxis <= angleTolerance)
    isAngle_NaxisVector_LessThanAll = np.logical_and(angle_Vector_Naxis <= angle_Vector_Haxis,
                                                     angle_Vector_Naxis <= angle_Vector_Vaxis,
                                                     angle_Vector_Naxis <= angleTolerance)
    # Fetch corresponding axis based on condition.
    closestAxisOfView_TemplateArray[np.where(isAngle_HaxisVector_LessThanAll)] = angle_Vector_Haxis[
        isAngle_HaxisVector_LessThanAll]
    closestAxisOfView_TemplateArray[np.where(isAngle_VaxisVector_LessThanAll)] = angle_Vector_Vaxis[
        isAngle_VaxisVector_LessThanAll]
    closestAxisOfView_TemplateArray[np.where(isAngle_NaxisVector_LessThanAll)] = angle_Vector_Naxis[
        isAngle_NaxisVector_LessThanAll]
    return closestAxisOfView_TemplateArray


def mappedDirection_FromViewMatrices2(rotationMatrix1: np.ndarray,
                                      rotationMatrix2: np.ndarray, rotationMatrix1_Direction: np.ndarray):
    """
    Computes mapped direction from view matrices.
    Args:
        rotationMatrix1: Numpy array of shape (n,3,3)
        rotationMatrix2: Numpy array of shape (n,3,3)
        rotationMatrix1_Direction: Numpy array of shape (n, 1) - only one of  {'H', 'X', 'V', 'Y', 'N', 'Z'}
    Returns: Mapped direction from view matrices
    """
    # Convert the directions to uppercase characters.
    rotationMatrix1_DirectionStr = np.char.upper(rotationMatrix1_Direction).astype(str)
    # Create a template array to populate it with direction.
    mappedDirection_FromViewMatrices_TemplateArray = np.full(shape=(len(rotationMatrix1), 1), fill_value=np.nan,
                                                             dtype=str)
    # Choose appropriate axis based on direction.
    conditions = [rotationMatrix1_DirectionStr == 'H',
                  rotationMatrix1_DirectionStr == 'X',
                  rotationMatrix1_DirectionStr == 'V',
                  rotationMatrix1_DirectionStr == 'Y',
                  rotationMatrix1_DirectionStr == 'N',
                  rotationMatrix1_DirectionStr == 'Z']
    choices = [rotationMatrix1[:, 0, :],
               rotationMatrix1[:, 0, :],
               rotationMatrix1[:, 1, :],
               rotationMatrix1[:, 1, :],
               rotationMatrix1[:, 2, :],
               rotationMatrix1[:, 2, :]]

    rotationMatrixAxis = np.select(condlist=conditions, choicelist=choices, default=np.array([np.nan, np.nan, np.nan]))

    # Check if the second rotation matrix is in the same direction as the axis of the first rotation matrix.
    # Get H,V and N axes of rotation matrix.
    rotationMatrix2_Haxis = rotationMatrix2[:, 0, :]
    rotationMatrix2_Vaxis = rotationMatrix2[:, 1, :]
    rotationMatrix2_Naxis = rotationMatrix2[:, 2, :]
    # Check for alignment
    isRotationMatrix2_Haxis_InSameDirection_RotationMatrixAxis = isSameDirection(rotationMatrix2_Haxis,
                                                                                 rotationMatrixAxis)
    isRotationMatrix2_Vaxis_InSameDirection_RotationMatrixAxis = isSameDirection(rotationMatrix2_Vaxis,
                                                                                 rotationMatrixAxis)
    isRotationMatrix2_Naxis_InSameDirection_RotationMatrixAxis = isSameDirection(rotationMatrix2_Naxis,
                                                                                 rotationMatrixAxis)
    # Assign corresponding direction upon fulfilling the respective condition.
    mappedDirection_FromViewMatrices_TemplateArray[isRotationMatrix2_Haxis_InSameDirection_RotationMatrixAxis] = 'H'
    mappedDirection_FromViewMatrices_TemplateArray[isRotationMatrix2_Vaxis_InSameDirection_RotationMatrixAxis] = 'V'
    mappedDirection_FromViewMatrices_TemplateArray[isRotationMatrix2_Naxis_InSameDirection_RotationMatrixAxis] = 'N'
    return mappedDirection_FromViewMatrices_TemplateArray


def matrixMultiply(matrix1: np.ndarray, matrix2: np.ndarray):
    """
    Returns the matrix multiplication of the given matrices.
    :param matrix1: A numpy array of shape (n,3)
    :param matrix2: A numpy array of shape (n,3)
    :return: result of matrix multiplication
    """
    return np.matmul(matrix1, matrix2)


def inverse(array: np.ndarray):
    """
    Computes the inverse of the given array
    :param array: A numpy array of shape (n,3)
    :return: Inverse of the given numpy array with shape (n,3)
    """
    return np.linalg.inv(array)


def compute_TransformationRotnMatrix_fromOneViewToOtherView(srcRotationMatrix: np.ndarray,
                                                            destRotationMatrix: np.ndarray):
    """
    Computes the transformation rotation matrix for thr given matrix.
    Args:
        srcRotationMatrix: A numpy array of shape (n,3,3)
        destRotationMatrix: A numpy array of shape (n,3,3)
    Returns: Transformation rotation matrix for thr given matrix.
    """
    # Ensure whether proper input is given.
    if not (np.shape(srcRotationMatrix)[0] != np.shape(destRotationMatrix)[0] and
            (np.shape(srcRotationMatrix[0]) > 1 and
             np.shape(destRotationMatrix)[0] > 1)):
        # Get inverse of rotationMatrix1
        invRotationMatrix = inverse(srcRotationMatrix)

        # Multiply view rotation matrix 2 and inverse of view rotation matrix 1
        resultantRotationMatrix = matrixMultiply(invRotationMatrix, destRotationMatrix)
        return resultantRotationMatrix
    else:
        raise Exception('Please give appropriate matrices as the input.')


def getUnitVectorAlongTheGivenAxis(axis: Literal["H", "V", "N", "X", "Y", "Z"], numRequired: int, dim: Optional = 3):
    """
    Computes the unit vector along given direction.
    Args:
        axis: The direction in which the unit vector is required.
        numRequired: Number of unit vectors required
        dim(default=3): Number of dimensions (whether two or three)

    Returns:Numpy array having 'numRequired' unit vectors in 'axis' direction having 'dim' dimensions
    """
    # If three-dimensional space is dealt, return unit vector in 2D along specified direction.
    if dim == 3:
        if axis.lower() == 'h' or axis.lower() == 'x':
            return np.full(shape=(numRequired, dim), fill_value=np.array([1, 0, 0]))

        if axis.lower() == 'v' or axis.lower() == 'y':
            return np.full(shape=(numRequired, dim), fill_value=np.array([0, 1, 0]))

        if axis.lower() == 'n' or axis.lower() == 'z':
            return np.full(shape=(numRequired, dim), fill_value=np.array([0, 0, 1]))
    # If two-dimensional space is dealt, return unit vector in 2D along specified direction.
    if dim == 2:
        if axis.lower() == 'h' or axis.lower() == 'x':
            return np.full(shape=(numRequired, dim), fill_value=np.array([1, 0]))

        if axis.lower() == 'v' or axis.lower() == 'y':
            return np.full(shape=(numRequired, dim), fill_value=np.array([0, 1]))


# todo: NDY
def relativeRotationMatrix(axisVector: np.ndarray, angleOfRotation: np.ndarray):
    """
        Creates relative rotation matrix for given axis of rotation
        and angle of rotation.
        Parameters:
            axisVector: A numpy array of shape (n, 3)
            angleOfRotation: A numpy array of shape (n, 1)
        Returns:
            Relative Rotation Matrix

    """
    return "Not Implemented Yet"


# todo: NDY
def rotateViewInGivenNormalDCs(expectedViewNormal: np.ndarray, oRotationMatrix3D: np.ndarray):
    """
    Computes the matrix required for rotating the given view with respect to normal.
    Args:
        expectedViewNormal: Numpy array of shape (n, 3)
        oRotationMatrix3D: Numpy array of shape (n, 3, 3)
    Returns:  Matrix required for rotating the given view with respect to normal.
    """

    return "Not Implemented Yet"


def normalClosestToGivenVector(inputVector: np.ndarray, rotationMatrix: np.ndarray):
    """
    Determines the normal closest to given vector.
    Args:
        inputVector: Numpy array of shape (n,3)
        rotationMatrix: Numpy array of shape (n,3,3)
    Returns: Normal closest to given vector.
    """
    # Create arrays from H,V and N axes of the rotation matrix.
    rotationMatrix_Haxis = rotationMatrix[:, 0, :]
    rotationMatrix_Vaxis = rotationMatrix[:, 1, :]
    rotationMatrix_Naxis = rotationMatrix[:, 2, :]
    # Compute included angles between input vector and H,V,N axes.
    includedAngle_InputVector_Haxis = includedAngle(inputVector, rotationMatrix_Haxis)
    includedAngle_InputVector_Vaxis = includedAngle(inputVector, rotationMatrix_Vaxis)
    includedAngle_InputVector_Naxis = includedAngle(inputVector, rotationMatrix_Naxis)
    # Create a template array to store the output vector.
    outputVectorArray = np.full(shape=(len(inputVector), 3), fill_value=np.array([np.nan, np.nan, np.nan]))

    # H axis
    # Make all angles <= 90 in minAngle array
    minAngleArray = np.where(includedAngle_InputVector_Haxis < 90, includedAngle_InputVector_Haxis, 90)
    # Consider H axis of the rotation matrix where angle not equal to 90 degrees.
    outputVectorArray[minAngleArray != 90] = rotationMatrix[:, 0, :][minAngleArray != 90]

    # V axis
    # Update minAngle array with Vaxis angle at indices where vAxis angle is lesser.
    minAngleArray = np.where(includedAngle_InputVector_Vaxis <= minAngleArray, includedAngle_InputVector_Vaxis,
                             minAngleArray)

    condition_V = np.logical_and(includedAngle_InputVector_Vaxis <= minAngleArray,
                                 includedAngle_InputVector_Vaxis != 90)
    # Consider V axis of rotation matrix where angle is less than minAngle and not equal to 90 degrees.
    outputVectorArray[condition_V] = rotationMatrix[:, 1, :][condition_V]

    # N axis
    # Update minAngle Array with Naxis angle if it is lesser than minAngle.
    minAngleArray = np.where(includedAngle_InputVector_Naxis <= minAngleArray, includedAngle_InputVector_Naxis,
                             minAngleArray)
    condition_N = np.logical_and(includedAngle_InputVector_Naxis <= minAngleArray,
                                 includedAngle_InputVector_Naxis != 90)
    # Consider Naxis where angle is lesser than minAngle and not equal to 90 degrees.
    outputVectorArray[condition_N] = rotationMatrix[:, 2, :][condition_N]
    return outputVectorArray


# TODO: NDY
def rotationMatrixFrom_GivenVector_InputMatrix(rotationMatrix1: np.ndarray, rotationMatrix2: np.ndarray):
    """
    Computes Rotation matrix from face normal and input matrix.
    Args:
        rotationMatrix1: Numpy array of shape (n,3,3).
        rotationMatrix2: Numpy array of shape (n,3,3).
    Returns: Rotation Matrix
    """
    # Get unit vectors for the horizontal, vertical and normal components.
    return "Not Implemented Yet"
