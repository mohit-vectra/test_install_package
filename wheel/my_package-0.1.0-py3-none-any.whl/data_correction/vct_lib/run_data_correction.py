import os
import json
import pandas as pd
import re
from data_correction.vct_lib.SD_Correction import Correction_FaceVec
from data_correction.vct_lib.SD_Correction import Correction_BodyName


def main(paths):
    # Check if input_path is None, empty, or invalid
    for partNumber, partConfig in paths.items():
        if isinstance(partConfig, dict):

            inputFiles = partConfig["input"]
            outputFiles = partConfig["output"]

            # Compile a regex pattern to match paths containing the specified output directory
            pattern = re.compile(rf'(^|[/\\]){"issue_report.json"}')

            # Filter tool_app_paths to find the one matching the pattern, and select the first match
            issueReport = [filePath for filePath in inputFiles if pattern.search(filePath)][0]

            # Store all the lines of the file in the list
            try:
                with open(issueReport, 'r') as jsonFile:
                    issuesDict = json.load(jsonFile)

            except FileNotFoundError:
                raise FileNotFoundError(f"Error report doesn't exist at {issueReport}")

            """
             TODO -> We need a program that reads the issuesDict and understands which files require correction. That o/p
             must be used to populate filesRequiringCorrection list.
            """
            filesRequiringCorrection = ['FaceVec.parquet', 'Body_Name.parquet']

            correctionConfig = {
                'facevec.parquet': correctFaceVec,
                'body_name.parquet': correctBodyName
            }

            for filePath in inputFiles:
                if "issue_report" in filePath:
                    continue

                fileName = filePath.split("\\")[-1]
                correctedFileName = fileName.lower().replace(" ", "_").replace(".parquet", "")

                data = None

                if "parquet" in fileName:
                    data = pd.read_parquet(filePath)

                elif "json" in fileName:
                    with open(filePath, "r") as file:
                        data = json.load(file)

                if correctedFileName in filesRequiringCorrection:
                    correctionConfig[correctedFileName](data, issuesDict)

                # Compile a regex pattern to match paths containing the specified output directory
                pattern = re.compile(rf'(^|[/\\]){correctedFileName}')

                # Filter tool_app_paths to find the one matching the pattern, and select the first match
                outputFilePath = [filePath for filePath in outputFiles if pattern.search(filePath)][0]

                if "parquet" in outputFilePath:
                    data.to_parquet(outputFilePath, index=False)

                if "json" in outputFilePath:
                    with open(outputFilePath, "w") as file:
                        json.dump(data, file)

            print(f"corrected data generation for {partNumber} successfully completed!")


# Correcting FaceVec
def correctFaceVec(dfFaceVec, issuesDict):
    # allCorrections_FaceVec = {'Feat name present, but hole size MISSING', 'Hole size present, but feat name MISSING'}
    # Currently issues_FV need not get any input. So, None is the default.
    objCorrection_FV = Correction_FaceVec(issuesDict, dataFrame_FV=dfFaceVec, issues_FV=None)
    objCorrection_FV.correctFeatName_HoleSize()
    print('FaceVec correction done')


# Correcting body name
def correctBodyName(dfBodyName, issuesDict):
    # allCorrections_BodyName = {'Stock size MISSING'}
    # Currently issues_BN need not get any input. So, None is the default.
    objCorrection_BodyName = Correction_BodyName(issuesDict, dataFrame_BN=dfBodyName, issues_BN=None)
    objCorrection_BodyName.correct_Shape()
    objCorrection_BodyName.correct_component()
    objCorrection_BodyName.correct_stockSize()
    print('Body Name correction done')
