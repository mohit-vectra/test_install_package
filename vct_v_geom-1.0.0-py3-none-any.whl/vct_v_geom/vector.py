import numpy as np
from typing import Union

ANGLE_TOLERANCE_1_DEG_PRL = 0.0001523
TOLERANCE = 0.1


# todo: Following functions are already tested.

def distanceToVector(vector1: np.ndarray, vector2: np.ndarray):
    """
    Computes distance between two vectors
    Args:
        vector1: numpy array of shape (n, 3)
        vector2: numpy array of shape (n, 3)
    Returns: Distance between two vectors
    """
    if vector1.ndim != vector2.ndim:
        raise ValueError(f'vector dimensions incompatible')

    distVect = directionVector(vector1, vector2)

    return magnitude(distVect)


def isOrthogonal(vector1: np.ndarray, vector2: np.ndarray):
    """
    Checks if two vectors are orthogonal
    Args:
        vector1: numpy array of shape (n, 3)
        vector2: numpy array of shape (n, 3)
    Returns: Boolean value indicating if the vectors are orthogonal
    """
    dotProd = dotProduct(vector1, vector2)
    orthogonality = abs(dotProd) < ANGLE_TOLERANCE_1_DEG_PRL
    return orthogonality


# Return the scalar product of the vector
def scalarProduct(vector: np.ndarray, scalar: Union[float, int]):
    """
    Computes scalar product of the vector
    Args:
        vector: numpy array of shape (n, 3)
        scalar: scalar value
    Returns: Scalar product of the vector
    """
    return scalar * vector


def crossProduct(vector1: np.ndarray, vector2: np.ndarray):
    """
    Computes cross product between vector1 and vector2
    Args:
        vector1: Numpy array of shape (n, 3).
        vector2: Numpy array of shape (n, 3).
    Returns: Cross product between vector1 and vector2.
    """
    return np.cross(vector1, vector2)


def dotProduct(vector1: np.ndarray, vector2: np.ndarray):
    """
    Computes dot product between vector1 and vector2
    Args:
        vector1: numpy array of shape (n, 3)
        vector2: numpy array of shape (n, 3)
    Returns: Dot product between vector1 and vector2
    """

    if vector1.ndim > 1 and vector2.ndim > 1:
        dotProd = np.einsum('ij, ij->i', vector1, vector2)
        # dotProd = np.einsum('...ij,ij->...i', vector1, vector2)
        return dotProd
    return np.dot(vector1, vector2)


def magnitude(vector: np.ndarray):
    """
    Computes magnitude of vector
    Args:
        vector: numpy array of shape (n, 3)
    Returns: Magnitude of vector
    """
    if vector.ndim == 1:
        length = np.linalg.norm(vector)
    else:
        length = np.linalg.norm(vector, axis=1)
        length = np.reshape(length, (-1, 1))
    return length


def isUnitVector(vector: np.ndarray):
    """
    Computes boolean mask indicating if each entry in the vector is a unit vector
    Args:
        vector: numpy array of shape (n, 3)
    Returns: Boolean mask
    """

    return np.linalg.norm(vector, axis=1) - 1 == 0


def parallel(vector1: np.ndarray, vector2: np.ndarray):
    """
    Determines if given vectors are parallel (params need to be of same shape)
    :param vector1: A numpy array of shape (n,3)
    :param vector2: A numpy array of shape (n,3)
    :return:  Boolean mask/array
    """

    unitized_vector1 = unitize(vector1)
    unitized_vector2 = unitize(vector2)

    dotProd = dotProduct(unitized_vector1, unitized_vector2)
    return abs(dotProd - 1) < ANGLE_TOLERANCE_1_DEG_PRL


def isAligned(vector1: np.ndarray, vector2: np.ndarray):
    """
    Computes the boolean mask for alignment between the given vectors (params need to be of same shape)
    :param vector1: Numpy array of shape (n,3)
    :param vector2: Numpy array of shape (n,3)
    :return: boolean mask/array
    """
    return (parallel(vector1, vector2)) | (antiParallel(vector1, vector2))


def antiParallel(vector1: np.ndarray, vector2: np.ndarray):
    """
    Determines if given vectors are anti parallel
    :param vector1: A numpy array of shape (n,3)
    :param vector2: A numpy array of shape (n,3)
    :return: Boolean mask/array
    """

    dotProd = dotProduct(unitize(vector1), unitize(vector2))
    return abs(dotProd + 1) < ANGLE_TOLERANCE_1_DEG_PRL


def isSameDirection(vector1: np.ndarray, vector2: np.ndarray):
    """
    Determines if vector1 and vector2 are in same direction
    :param vector1: Numpy array of shape (n, 3)
    :param vector2: Numpy array of shape (n, 3)
    :return: Boolean value indicating if vectors are in same direction
    """
    vectorDotProduct = dotProduct(vector1, vector2)

    return np.abs((np.abs(vectorDotProduct) - 1)) < ANGLE_TOLERANCE_1_DEG_PRL


def orthogonalVector(vector: np.ndarray):
    """
    Computes orthogonal vector
    Args:
        vector: A numpy array of shape (n,3)
    Returns:A numpy array of shape (n,3) where each element is a component of orthogonal vector

    """
    # Check if z component is non zero.
    cond1 = vector[:, 2] != 0

    # check if y component is non-zero and z is zero
    cond2 = np.logical_and(vector[:, 2] == 0, vector[:, 1] != 0)
    # check if x component is non-zero and y,z components being zeros
    cond3 = np.logical_and(vector[:, 0] != 0,
                           np.logical_and(vector[:, 2] == 0, vector[:, 1] == 0))

    # Compute z component of orthogonal vector.
    zcompArr = vector[cond1]
    zcompArr[:, 2] = (zcompArr[:, 0] + zcompArr[:, 1]) / -1 * zcompArr[:, 2]
    zcompArr[:, 1] = 1
    zcompArr[:, 0] = 1
    vector[np.where(cond1)] = zcompArr

    # Compute y component of orthogonal vector.
    ycompArr = vector[cond2]
    ycompArr[:, 1] = (ycompArr[:, 0] + ycompArr[:, 2]) / (-1 * ycompArr[:, 1])
    ycompArr[:, 0] = 1
    ycompArr[:, 2] = 1
    vector[np.where(cond2)] = ycompArr

    # Compute x component of orthogonal vector.
    xcompArr = vector[cond3]
    xcompArr[:, 0] = (xcompArr[:, 2] + xcompArr[:, 1]) / -1 * xcompArr[:, 0]
    xcompArr[:, 1] = 1
    xcompArr[:, 2] = 1
    vector[np.where(cond3)] = xcompArr
    return vector


def includedAngle(vector1: np.ndarray, vector2: np.ndarray):
    """
    Computes the included angle between vector1 and vector2.
    Args:
        vector1: Numpy array of shape (n, 3)
        vector2: Numpy array of shape (n, 3)
    Returns:
        Included angle between vector1 and vector2
    """
    unitVect1 = unitize(vector1)
    unitVect2 = unitize(vector2)
    dotProd = dotProduct(unitVect1, unitVect2)
    # Check if dot product is less than -1
    isDotProd_LessThanNegativeOne = dotProd < -1
    # Check if dot product is greater than 1
    isDotProd_GreaterThanPositiveOne = dotProd > 1
    dotProd[isDotProd_LessThanNegativeOne] = -1
    dotProd[isDotProd_GreaterThanPositiveOne] = 1
    angle = np.arccos(dotProd) * 180 / np.pi

    return angle


def unitize(vector: np.ndarray):
    """
    unitizes/Normalizes the given vector
    :param vector: A numpy array.
    :return: unitized vector of  the given vector.
    """
    length = None
    if vector.ndim == 1:
        # Magnitude of vector
        length = np.linalg.norm(vector)
    elif vector.ndim == 2:
        length = np.linalg.norm(vector, axis=1)
        length = np.reshape(length, (-1, 1))
    elif vector.ndim == 3:
        length = np.linalg.norm(vector, axis=2)
        length = np.reshape(length, (-1, 1, 1))
    unitizedVector = vector / length
    return unitizedVector


def directionVector(vector1: np.ndarray, vector2: np.ndarray):
    """
    computes the direction vector of the given vectors
    :param vector1: A numpy array of shape (n,3).
    :param vector2: A numpy array of shape (n,3).
    :return: Direction vector of shape (n,3) of the given vectors.
    """
    return vector2 - vector1


def vectorDirection(vector, referenceVectors=None, labels=None):
    """
    Determine the direction alignment of input vectors with reference vectors.
    Parameters:
    vector (ndarray): An array of input vectors to be checked.
    referenceVectors (ndarray, optional)
    labels (ndarray, optional): An array of labels corresponding to the reference vectors.
                                Defaults to ['H', '-H', 'V', '-V', 'N', '-N'].
    Returns:
    ndarray: An array of assigned labels based on the alignment of each input vector.
    """
    if referenceVectors is None:
        referenceVectors = np.array([
            [1, 0, 0],
            [-1, 0, 0],
            [0, 1, 0],
            [0, -1, 0],
            [0, 0, 1],
            [0, 0, -1]
        ])

    if labels is None:
        labels = np.array(['H', '-H', 'V', '-V', 'N', '-N'])

    # Expand dimensions of vectors for broadcasting
    vectorsExpanded = np.expand_dims(vector, axis=1)

    # Compare each input vector with reference vectors
    isAlign = np.all(np.isclose(vectorsExpanded, referenceVectors, atol=ANGLE_TOLERANCE_1_DEG_PRL), axis=2)

    # Find the indices of the matching vectors
    fetchIndices = np.argmax(isAlign, axis=1)

    # Determine if there was a match for each vector
    aligned = np.any(isAlign, axis=1)

    # Assign labels based on matches
    assignedLabels = np.where(aligned, labels[fetchIndices], 'C')

    return assignedLabels
