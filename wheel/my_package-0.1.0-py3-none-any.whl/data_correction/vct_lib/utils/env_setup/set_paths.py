import os  # Import the os module for interacting with the operating system
import json  # Import the json module for handling JSON data
import re  # Import the re module for working with regular expressions
import pandas as pd
import data_correction.vct_lib.utils.env_setup.read as read
import data_correction.vct_lib.utils.env_setup.validate_directory as vd
import data_correction.vct_lib.utils.env_setup.make_directory as md


class PathManager:
    def __init__(self, global_paths, package_file_paths):
        self.global_paths = global_paths
        self.package_file_paths = package_file_paths

    def getProgramPaths(self):
        return {
            'input': self.global_paths["input"],
            'output': self.global_paths["output"],
            'feeder_file': self.global_paths["feeder_file"].replace("txt", "csv"),
            'log_dir': self.global_paths["log_dir"]
        }

    def getLogFiles(self, project_name):
        return {
            'resume': os.path.join(self.global_paths["log_dir"],
                                   f"{project_name}_{self.package_file_paths['restart_file']}"),
            'completion': os.path.join(self.global_paths["log_dir"],
                                       f"{project_name}_{self.package_file_paths['completion_file']}"),
            'failure': os.path.join(self.global_paths["log_dir"], f"{self.package_file_paths['failure_file']}")
        }

    def getProgramFiles(self, program_type):
        return self.package_file_paths.get(f"{program_type}_files", "")


class DirectoryManager:
    @staticmethod
    def createDirectory(path):
        if not os.path.exists(path):
            print(f"{path} does not exist. Creating it....")
            os.makedirs(path)
        else:
            print(f"{path} exists")


class PackagePathGenerator:
    def __init__(self, path_manager):
        self.path_manager = path_manager
        self.parser_config = {"parts_list": []}
        self.feeder_file_data = {"parts_list": [], "program_complete": [], "program_success": []}

    def generatePaths(self, part_paths, project_name):
        paths = self.path_manager.getProgramPaths()
        program_input_path = paths['input']
        program_output_path = paths['output']
        feeder_files = paths['feeder_file']
        log_files = self.path_manager.getLogFiles(project_name)
        psd_prefix = self.path_manager.package_file_paths["psd_prefix"]

        for part_path in part_paths:
            self._processPartPath(part_path, psd_prefix, program_input_path, program_output_path)

        self._finalizeConfiguration(feeder_files, log_files)

        return self.parser_config

    def _processPartPath(self, part_path, psd_prefix, program_input_path, program_output_path):
        if psd_prefix in part_path:
            part_name = self._getPartName(part_path, psd_prefix)
            input_paths = self._getInputPaths(part_name, program_input_path, part_path)
            output_paths = self._getOutputPaths(part_name, program_output_path)

            DirectoryManager.createDirectory(os.path.join(program_output_path, part_name))

            self.parser_config[part_name] = {"input": input_paths, "output": output_paths}
            self.parser_config["parts_list"].append(part_name)

    def _getPartName(self, part_path, psd_prefix):
        return ((part_path.replace(psd_prefix, "")).replace(".xlsm", "")).split('\\')[-1]

    def _getInputPaths(self, part_name, program_input_path, part_path):
        if not program_input_path:
            return [part_path]

        input_part_dir = os.path.join(program_input_path, part_name)
        input_files = self.path_manager.getProgramFiles(program_input_path.split("\\")[-1])

        if not input_files:
            return [part_path]

        return [os.path.join(input_part_dir, input_file) for input_file in input_files]

    def _getOutputPaths(self, part_name, program_output_path):
        output_part_dir = os.path.join(program_output_path, part_name)
        output_files = self.path_manager.getProgramFiles(program_output_path.split("\\")[-1])

        return [os.path.join(output_part_dir, output_file) for output_file in output_files]

    def _finalizeConfiguration(self, feeder_files, log_files):
        feeder_file_df = pd.DataFrame(self.feeder_file_data)
        feeder_file_df.to_csv(feeder_files, index=False)

        self.parser_config["feeder_file"] = feeder_files
        self.parser_config["resume_file"] = log_files['resume']
        self.parser_config["completion_file"] = log_files['completion']
        self.parser_config["failure_file"] = log_files['failure']


class Global:

    @classmethod
    def get_TargetDir_Tool(cls, tool_app_paths, target_dir):
        """
        Create the full path for the temporary data directory by combining the output
        directory with the specific output directory specified in the runtime JSON.
        """
        # Compile a regex pattern to match paths containing the specified output directory
        pattern = re.compile(rf'(^|[/\\]){target_dir}($|[/\\])')

        # Filter tool_app_paths to find the one matching the pattern, and select the first match
        directory = [tool_app_path for tool_app_path in tool_app_paths if pattern.search(tool_app_path)][0]

        # Return the matched directory
        return directory

    @classmethod
    def programDir_Tool_IO(cls, io_Dir, package_dir_paths,
                           project_name, io="input"):
        """
        Create the full path for the temporary data directory by combining the output
        directory with the specific output directory specified in the runtime JSON.
        """

        if io == 'input' and package_dir_paths["program_io"][project_name][f"{io}_dir"] == "":
            fullPath = ""
            return fullPath

        # Create the full path by joining target_dir with the program_output_dir from package_dir_paths
        fullPath = os.path.join(io_Dir, package_dir_paths["program_io"][project_name][f"{io}_dir"])

        # Check if the fullPath exists, if not, create it
        if not os.path.exists(fullPath):
            print(f"{fullPath} does not exist, creating it....")
            os.makedirs(fullPath)

        # Inform the user that the fullPath exists
        print(f"{fullPath} exists")
        return fullPath

    @classmethod
    def feederFile(cls, tool_path, package_file_paths, package_dir_paths, project_name):
        print(tool_path)
        feederFileDir = os.path.join(tool_path, package_dir_paths["feeder_files"])

        if not os.path.exists(feederFileDir):
            print("Feeder file dir, doesnt exist, creating it...")
            os.makedirs(feederFileDir)
        else:
            print("Feeder file dir exists")

        feederFile_Files = f"{package_file_paths['program_prefix'][project_name]}_{package_file_paths['parts_data']}"
        feederFile_FilesPath = os.path.join(feederFileDir, feederFile_Files)

        return feederFile_FilesPath
        # if not os.path.exists(feederFile_FilesPath):
        #     print(f"{feederFile_Files}, doesnt exist, creating it...")
        #
        #     with open(feederFile_FilesPath, "w") as file:
        #
        # else:
        #     print("{feederFile_Files} exists")

    @classmethod
    def get_PartPaths(cls, tool_app_paths, package_dir_paths, package_file_paths):
        # Get the parts_info directory from package_dir_paths
        searchIn = package_dir_paths["parts_info"]

        # Compile a regex pattern to match paths containing the parts_info directory
        pattern = re.compile(rf'(^|[/\\]){searchIn}($|[/\\])')

        # Filter tool_app_paths to find the one matching the pattern, and select the first match
        directory = [tool_app_path for tool_app_path in tool_app_paths if pattern.search(tool_app_path)][0]

        # Create the full path for parts_data by joining the directory with parts_data from package_file_paths
        partsPath = os.path.join(directory, package_file_paths["parts_data"])

        # Return the constructed partsPath
        return partsPath

    @classmethod
    def set_GlobalFilePaths(cls, program_input_dir, program_output_dir, program_log_dir,
                            part_paths, feeder_file_paths):
        # Create a dictionary with the parts_list and output paths
        gfp = {
            "parts_list": part_paths,
            "log_dir": program_log_dir,
            "feeder_file": feeder_file_paths,
            "input": program_input_dir,
            "output": program_output_dir
        }
        # Return the dictionary containing global file paths
        return gfp

    @classmethod
    def extract(cls, tool_app_paths, package_dir_paths, package_file_paths, project_name):
        """
        Extract the configuration path from the runtime environment settings and
        read the Auto2DServer configuration file to get the output directory.
        """
        # Get the output directory from package_dir_paths
        outputDir = package_dir_paths["output_dir"]

        # Get the full output directory path using the get_TargetDir_Tool method
        tool_OutputDir = cls.get_TargetDir_Tool(tool_app_paths=tool_app_paths, target_dir=outputDir)

        # Get the full log directory path using the get_TargetDir_Tool method
        tool_LogDir = cls.get_TargetDir_Tool(tool_app_paths=tool_app_paths,
                                             target_dir=package_dir_paths["log_dir"])

        tool_FeederFiles = cls.feederFile(tool_path=tool_OutputDir, package_file_paths=package_file_paths,
                                          package_dir_paths=package_dir_paths, project_name=project_name)

        # Get the program output directory using the programDir_Tool_IO method
        tool_ProgramOutputDir = cls.programDir_Tool_IO(io_Dir=tool_OutputDir,
                                                       package_dir_paths=package_dir_paths,
                                                       io="output", project_name=project_name,
                                                       )

        # Get the program output directory using the programDir_Tool_IO method
        tool_ProgramInputDir = cls.programDir_Tool_IO(io_Dir=tool_OutputDir,
                                                      package_dir_paths=package_dir_paths,
                                                      project_name=project_name)

        # Get the part paths using the get_PartPaths method
        partPaths = cls.get_PartPaths(tool_app_paths=tool_app_paths,
                                      package_dir_paths=package_dir_paths,
                                      package_file_paths=package_file_paths)

        # Set global file paths using the set_GlobalFilePaths method
        globalDataPaths = cls.set_GlobalFilePaths(program_input_dir=tool_ProgramInputDir,
                                                  program_output_dir=tool_ProgramOutputDir,
                                                  program_log_dir=tool_LogDir,
                                                  part_paths=partPaths, feeder_file_paths=tool_FeederFiles)

        # Return the dictionary containing global data paths
        return globalDataPaths


class Local:

    @classmethod
    def get_AppData_FilePaths(cls):
        # Open and read the application data paths from a JSON file
        with open("./app_data/dir_constants.json", 'r') as file:
            data = json.load(file)

        # Return the loaded JSON data
        return data

    @classmethod
    def get_GlobalPaths(cls):
        # Open and read the global paths from a JSON file
        with open("global_set_paths.json", 'r') as file:
            data = json.load(file)

        # Return the loaded JSON data
        return data

    @classmethod
    def read_AppData_FileConstants(cls):
        # Open and read the file constants from a JSON file
        with open("./app_data/file_constants.json", 'r') as file:
            data = json.load(file)

        # Return the loaded JSON data
        return data

    @classmethod
    def partsFilePaths(cls, filePath):
        # Open and read the configuration file, splitting into lines
        with open(filePath, "r") as file:
            data = file.read().splitlines()

        # Return the list of file paths
        return data

    @classmethod
    def get_PartPaths(cls, global_paths):
        # Get the parts list file paths from global paths
        filePaths_Parts = cls.partsFilePaths(global_paths["parts_list"])
        # Return the parts file paths
        return filePaths_Parts

    @classmethod
    def get_PackageOutputPath(cls, part_paths_dict, output_dir, output_files):
        # Iterate through each part name and configuration in part_paths_dict
        for partName, config in part_paths_dict.items():
            # Initialize an empty list for output files
            outputFiles = []
            # Construct the path directory by joining output and partName
            pathDir = os.path.join(config["output"], partName)
            # Construct the parser output directory
            parserOutputDir = os.path.join(pathDir, output_dir)

            # Create the parser output directory if it does not exist
            if not os.path.isdir(parserOutputDir):
                os.makedirs(parserOutputDir)

            # Append each output file path to the outputFiles list
            for file in output_files:
                outputFiles.append(os.path.join(parserOutputDir, file))

            # Update the part_paths_dict with the new output paths
            part_paths_dict[partName]["output"] = outputFiles

        # Return the updated part_paths_dict
        return part_paths_dict

    @classmethod
    def get_PackagePaths(cls, part_paths, package_file_paths, global_paths, project_name):

        path_manager = PathManager(global_paths, package_file_paths)
        package_path_generator = PackagePathGenerator(path_manager)
        parser_config = package_path_generator.generatePaths(part_paths, project_name)

        return parser_config

    @classmethod
    def extract(cls, global_paths, package_file_paths, project_name):
        # Extract the parts file paths
        partPaths = cls.get_PartPaths(global_paths)

        # Get the data parser configuration
        packageConfig = cls.get_PackagePaths(partPaths, package_file_paths, global_paths, project_name)

        # Return the data parser configuration
        return packageConfig


def identifyLocalPaths(env, project_name):
    # Get the directory of the current script
    current_dir = os.path.dirname(__file__)

    currentDirList = current_dir.split("\\")
    idx_ProjectRoot = currentDirList.index(project_name)
    nextIdx_ProjectRoot = idx_ProjectRoot + 1

    currentDirList = currentDirList[:nextIdx_ProjectRoot]
    current_dir = "\\".join(currentDirList)

    # Construct the path to the config directory
    config_dir = os.path.join(current_dir, 'config')

    # Dictionary mapping environment types to their respective configuration classes
    envConfig = {
        "PROD": read.Production
    }

    # Get the configuration class for the specified environment
    envObject = envConfig[env.upper()]

    # Load various JSON configuration files using methods from the configuration class
    runtimeJSON = envObject.runtimeJSON(config_dir)
    outputDirJSON = envObject.outputDirJSON(config_dir)
    packageDirPathsJSON = envObject.packageDirPaths(config_dir)
    packageFilePathsJSON = envObject.packageFilePaths(config_dir)

    # Extract specific configurations for the environment from the loaded JSON data
    env_Runtime = runtimeJSON[env]
    env_OutputDir = outputDirJSON[env]
    env_PackageDirPaths = packageDirPathsJSON[env]
    env_PackageFilePaths = packageFilePathsJSON[env]

    # Extract the output directory path from the runtime configuration
    outputDirPath = envObject.extractOutputDirPath(runtime_json=env_Runtime)

    # Validate the output directory using utility functions
    vd.outputDir(file_path=outputDirPath)
    vd.directoryStructure(file_path=outputDirPath, output_dir_json=env_OutputDir)

    # Get the tool path and tool name using methods from the configuration class
    toolPath = envObject.toolPath(outputDirPath)
    toolName = envObject.toolName(toolPath)

    # Create the tool's directory structure using a utility function
    appPaths_ToTool = md.tool(tool_name=toolName, output_dir_json=env_OutputDir, file_path=outputDirPath)

    # Extract global paths using the set_paths module
    globalPaths = Global.extract(tool_app_paths=appPaths_ToTool, package_dir_paths=env_PackageDirPaths,
                                 package_file_paths=env_PackageFilePaths, project_name=project_name)

    # Extract local paths using the set_paths module
    localPaths = Local.extract(global_paths=globalPaths, package_file_paths=env_PackageFilePaths,
                               project_name=project_name)

    return localPaths  # Return the extracted local paths


if __name__ == "__main__":
    Global.extract("")
    # Call the extract method of the Global class with an empty string argument
    # This line is likely for testing purposes and will execute the extract method
