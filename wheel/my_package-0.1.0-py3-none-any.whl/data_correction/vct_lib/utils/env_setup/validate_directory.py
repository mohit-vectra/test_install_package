import os


def outputDir(file_path):
    if not os.path.exists(file_path):
        # TODO: Log instead of print
        print(f"Creating directory")
        os.makedirs(file_path)

    else:
        # TODO: Log instead of print
        print(f"Directory already exists")


def directoryStructure(file_path, output_dir_json):
    folders = output_dir_json["FOLDERS"]
    for folderName in folders:
        folderPath = os.path.join(file_path, folderName)\

        if not os.path.exists(folderPath):
            # TODO: Log instead of print
            print(f"{folderName} does not exist, creating it...")
            os.makedirs(folderPath)

        else:
            # TODO: Log instead of print
            print(f"{folderName} already exists")