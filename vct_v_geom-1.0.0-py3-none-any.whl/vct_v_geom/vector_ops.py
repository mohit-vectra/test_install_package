from typing import List
from vct_v_geom.vector import *
from vct_v_geom.point import *


def computeLineEndPoint(startPoint: np.ndarray, lineVector: np.ndarray, distance: np.ndarray):
    lineEndPoints = startPoint + (lineVector * distance[:, np.newaxis])
    return lineEndPoints


# todo: NDY
def intersectionPointBetweenTwoRays(ray1_StartPoint: np.ndarray, ray1_VectorDCs: np.ndarray,
                                    ray2_StartPoint: np.ndarray, ray2_VectorDCs: np.ndarray):
    """
    Computes the intersection point between two rays
    :param ray1_StartPoint: Start point of the first ray
    :param ray1_VectorDCs: Direction cosines of first ray
    :param ray2_StartPoint: Start point of the second ray
    :param ray2_VectorDCs: Direction cosines of second ray
    :return:
    """
    return "Not Implemented yet"


def isCoAxial(vector1: np.ndarray, vector2: np.ndarray, point1: np.ndarray, point2: np.ndarray):
    """
    Determines whether the given faces are co-axial.
    Args:
        vector1: A numpy array of shape (n,3)
        vector2: A numpy array of shape (n,3)
        point1: A numpy array of shape (n,3)
        point2: A numpy array of shape (n,3)
    Returns:A boolean mask indicating the co-axiality.
    """

    # Check for alignment.
    alignmentCheck = isAligned(vector1, vector2)
    # Compute orthogonal vector of vector1.
    orthogonalVectors = orthogonalVector(vector1)
    # Compute projected distance and compare if it is under permissible tolerance.
    projectedDistance = projectedDistance_TwoPoints(point1, point2,
                                                    orthogonalVectors)
    tolerance = 1e-5
    toleranceCheck = np.abs(projectedDistance) < tolerance
    # Compute co axiality mask based on alignment and projected distance
    coAxialityMask = alignmentCheck & toleranceCheck
    return coAxialityMask


def getEquationOfPlane_GivenNormalAnd_PointOnPlane(normal: np.ndarray, pointOnPlane: np.ndarray):
    # todo: can be Renamed to "getEquationOfPlane_givenNormalAnd_A_PointOnPlane"?
    """
    Computes the equation of the plane given the normal and a point
    Args:
        normal: Numpy array of shape (n,3).
        pointOnPlane: Numpy array of shape (n,3).
    Returns:Co-efficients of equation of plane formed by given normal and point.(Numpy array of shape (n,4))

    """
    # todo:->varma sir do we come across a situation to make multiple planes from multiple sets of 3 points?
    d = (-1 * (normal[:, 0] * pointOnPlane[:, 0] + normal[:, 1] * pointOnPlane[:, 1] + normal[:, 2] * pointOnPlane[:, 2]
               ).reshape(-1, 1))

    return np.hstack((normal, d))


def equationOfPlane_3Points(point1: np.ndarray, point2: np.ndarray, point3: np.ndarray):
    """
    Computes the equation of plane given three points
    Args:
        point1: Numpy array of shape (n,3)
        point2: Numpy array of shape (n,3)
        point3: Numpy array of shape (n,3)
    Returns: Equation of plane(Numpy array of shape n,4)

    """
    a1 = directionVector(point2, point1)
    a2 = directionVector(point2, point3)
    normal_vector = np.cross(a1, a2)
    equationOfPlane = getEquationOfPlane_GivenNormalAnd_PointOnPlane(normal=normal_vector, pointOnPlane=point2)
    return equationOfPlane


def pointsBelongsToPlane(arrayEquationsOfPlanes: np.ndarray, arrayPoints: np.ndarray):
    """
    Determines if the given point belongs to the equation of plane.
    Args:
        arrayEquationsOfPlanes: Numpy array of shape (n,4)
        arrayPoints: Numpy array of shape (n,3)
    Returns:A boolean mask indicating whether given point belongs to the plane.

    """
    # todo:Varma sir ->Can we rename the func name to isPointOnPlane?
    listBooleans_PointOnPlane = []
    for points, equationOfPlane in zip(arrayPoints, arrayEquationsOfPlanes):
        nestedPoint = points[0]
        allPointsFromThirdIndex = list(nestedPoint[3:, :])
        isPointOnPlane = None
        for eachPoint in allPointsFromThirdIndex:
            a = equationOfPlane[0]
            b = equationOfPlane[1]
            c = equationOfPlane[2]
            d = equationOfPlane[3]
            point_XcoOrdinate = eachPoint[0]
            point_YcoOrdinate = eachPoint[1]
            point_ZcoOrdinate = eachPoint[2]
            # todo:Varma sir -> Seek suggestion for good var name.
            pointOnPlane = a * point_XcoOrdinate + b * point_YcoOrdinate + c * point_ZcoOrdinate + d
            isPointOnPlane = np.abs(pointOnPlane) < 0.001
        listBooleans_PointOnPlane.append(isPointOnPlane)
    booleanMaskCoplanarity = np.array(listBooleans_PointOnPlane).reshape(len(listBooleans_PointOnPlane), 1)
    return booleanMaskCoplanarity


isPointOnPlaneFunc_Vectorized = np.vectorize(pointsBelongsToPlane, otypes=[np.ndarray], signature='(n,m),(n,1)->(n,1)')


def constructMyArray(array: np.ndarray, numOfEvaluations: int = 1):
    """
    Returns a numpy array containing "numOfEvaluations" numpy arrays as its elements
    :param array: Numpy array
    :param numOfEvaluations: number of cases to evaluate (coPlanarity)
    :return: Customised array
    """
    custArr = np.full(shape=(numOfEvaluations,), fill_value=object(), dtype=object)
    if numOfEvaluations == 1:
        custArr[0] = array
        return custArr
    for idx, arr in enumerate(array):
        custArr[idx] = arr
    return custArr


def getReShapedArray(array: np.ndarray):
    """
    Returns a reshaped numpy array based on the number of dimensions it has.
    :param array:
    :return:
    """
    if array.ndim == 2:
        return constructMyArray(array)
    if array.ndim == 3:
        return constructMyArray(array, numOfEvaluations=array.shape[0])


def coPlanar(list_points: np.ndarray):
    """
    Determines whether given set points of points are coplanar.
    Args:
        list_points: 2 or 3 Dimensional numpy array
    Returns: Boolean mask indicating coplanarity
    """
    # If the points exceed three dimensions or points is an empty numpy array
    if (not (2 <= list_points.ndim <= 3)) or (list_points.size == 0):
        raise TypeError("Expecting a non-zero sized numpy array with 2 or 3 dimensions")

    # When there is only one set of 3D points to be dealt with,
    if list_points.ndim == 2:
        dimEachPoint = list_points.shape[1]
        numberOfPoints = list_points.shape[0]
        if dimEachPoint != 3:
            raise TypeError("Each point in the given 2D numpy array must be 3 dimensional")
        if numberOfPoints <= 3:
            return np.array([True])

    # When 3D array is given, list_points can only be (n x m x 3) or (n x n x 3)
    elif list_points.ndim == 3:
        shapeOfListPoints = list_points.shape
        numOfEvaluations = shapeOfListPoints[0]
        numPointsInEachEvaluation = shapeOfListPoints[1]
        dimEachPoint = shapeOfListPoints[2]
        if dimEachPoint != 3:
            raise TypeError("All points must be 3 dimensional")
        # if m in the shape n x m x 3 is less than 3, all cases are true
        if numPointsInEachEvaluation <= 3:
            return np.array([True] * numOfEvaluations)

    list_points = getReShapedArray(list_points)

    isCoplanar = np.full(shape=(len(list_points),), fill_value=False)

    array_FirstThreePoints = np.array([array[:3, :] for array in list_points])

    # Compute the equation of plane formed by first three points in the set of arrays that are having len >=4.
    point1Array = array_FirstThreePoints[:, 0, :]
    point2Array = array_FirstThreePoints[:, 1, :]
    point3Array = array_FirstThreePoints[:, 2, :]

    equationOfPlane = equationOfPlane_3Points(point1=point1Array,
                                              point2=point2Array,
                                              point3=point3Array)
    list_points = np.reshape(list_points, newshape=(len(list_points), 1))
    subsetMask_IsCoplanar = isPointOnPlaneFunc_Vectorized(equationOfPlane, list_points
                                                          ).reshape(len(list_points), )
    # Update the mask to indicate coplanarity for all potential cases.
    isCoplanar[np.where(~isCoplanar)] = subsetMask_IsCoplanar
    return isCoplanar


def pointInPolygon_RayCasting(polygon: List[List[float]], point: List[Union[float, int]]):
    """
    Determines whether point is inside polygon. Args: polygon:List having vertices of a vertex loop in order.
    point:Vertex at epsilon distance to the given vertex of the polygon - Numpy array of shape (1,3)
    ray:A direction vector obtained by vector addition of two adjacent edges(vectors) of the polygon - Numpy array of
         shape (1, 3)
    Returns:Boolean value indicating whether the given point is inside the polygon
    """
    intersectionCount = 0
    ray = unitize(directionVector(np.array(polygon[0]), np.array(polygon[1]))).reshape(1, 3)
    for index in range(len(polygon)):
        activeIndex = index
        if index == len(polygon) - 1:
            nextIndex = 0
        else:
            nextIndex = index + 1
        # Tuple with two lists having vertices of active edge of the polygon (vertex loop)
        polygonEdge = (polygon[activeIndex], polygon[nextIndex])
        # Compute intersection point
        intersectionPt = intersectionPt_Ray_LineSegment(point, ray, polygonEdge)
        # Count intersection points of ray direction vector with the edges in polygon.
        if intersectionPt is not None:
            intersectionCount += 1

    # True if the number of intersections is odd.
    return intersectionCount % 2 == 1


def intersectionPt_Ray_LineSegment(ray_st_point: np.ndarray, rayDirVec: np.ndarray,
                                   lineSegment: List[List[Union[int, float]]]):
    """
    Computes the intersection point
    Args:
        ray_st_point: Starting point of the ray direction vector - Numpy array of shape (1,3)
        rayDirVec:Vector obtained by addition of two adjacent vectors of the polygon -Numpy array of shape (1,3)
        lineSegment: edge of the polygon - List two lists each being a point on the line segment
    Returns: Intersection point

    """
    endPoint1_OfLineSeg = np.reshape(np.array(lineSegment[0]), newshape=(1, 3))
    endPoint2_OfLineSeg = np.reshape(np.array(lineSegment[1]), newshape=(1, 3))
    lineSegVector = endPoint2_OfLineSeg - endPoint1_OfLineSeg

    rayVector = rayDirVec

    # No intersection between two parallel/anti-parallel lines.
    if isAligned(lineSegVector, rayVector):
        return None

    # Left normal vectors of line segment and the ray.
    planeNormal = np.cross(lineSegVector, rayVector)
    leftNormalLinseg = np.cross(planeNormal, lineSegVector)
    leftNormalRay = np.cross(planeNormal, rayVector)

    dotProd_RayLineSeg = dotProduct(rayVector, leftNormalLinseg)
    dotProd_LineSegNormalRay = dotProduct(lineSegVector, leftNormalRay)

    scalar_Ray = dotProduct((endPoint1_OfLineSeg - ray_st_point), leftNormalLinseg) / dotProd_RayLineSeg
    scalar_LS = dotProduct((ray_st_point - endPoint1_OfLineSeg), leftNormalRay) / dotProd_LineSegNormalRay

    # Compute intersection point.
    if (0 < scalar_Ray or abs(scalar_Ray) < 1e-5) and ((0 < scalar_LS or abs(scalar_LS) < 1e-5) and
                                                       (scalar_LS < 1 or abs(abs(scalar_LS) - 1) < 1e-5)):
        intersectionPoint = ray_st_point + (scalar_Ray * rayVector)
    else:
        intersectionPoint = None
    return intersectionPoint


def areasOfVertexLoops(vertexLoopsList: List[Union[int, float]]):
    """
    Computes areas of all vertex loops
    Args:
        vertexLoopsList (list): List having vertex loops
    Returns: areas of all vertex loops.
    (Assumption: All vertex loops consist greater than two vertices)
    """
    if not vertexLoopsList:
        return None
    areasOfAllVertexLoops = list(map(polygonArea, vertexLoopsList))
    return areasOfAllVertexLoops


def polygonArea(PolygonVertices: List[List[Union[int, float]]]):
    """
    Computes the area of the 2D polygon in 3D space.
    Args:
        PolygonVertices: vertices of the polygon in either clockwise or anti-clockwise direction. - list of lists
    Returns: Area of the given polygon
    Note: Designed to handle only a single set of points at a time.
    """
    # Return none if polygon has less than three vertices (EdgeCase for current implementation.)
    if len(PolygonVertices) < 3:
        return np.nan

    # RefVertex remains the same throughout the function execution.
    refVertex = PolygonVertices[0]
    # Assume that the area of the polygon is zero
    areaVector = 0
    vertex1_Index = 1
    vertex2_Index = 2

    while vertex2_Index != len(PolygonVertices):
        vertex1 = np.reshape(np.array(PolygonVertices[vertex1_Index]), newshape=(1, 3))
        vertex2 = np.reshape(np.array(PolygonVertices[vertex2_Index]), newshape=(1, 3))
        directionVec_1 = directionVector(refVertex, vertex1)
        directionVec_2 = directionVector(refVertex, vertex2)
        # Compute the area for polygon formed by refVertex,vertex1,vertex2 (Triangle)
        Half_crossProduct = np.cross(directionVec_1, directionVec_2) / 2
        areaVector = areaVector + Half_crossProduct
        # update the indices
        vertex1_Index += 1
        vertex2_Index += 1
    areaOfPolygon = np.linalg.norm(areaVector)
    return areaOfPolygon


def distanceBetween_ParallelLines(pointOnLine1: np.ndarray, pointOnLine2: np.ndarray, line1DCs: np.ndarray):
    """
    Computes distance between two parallel lines.
    Args:
        pointOnLine1: A numpy array of shape (n,3) or (n,2) with each entry being a point on line 1.
        pointOnLine2: A numpy array of shape (n,3) or (n,2) with each entry being a point on line 2.
        line1DCs: A numpy array of shape (n,3) or (n,2) with each array being DCs of given lines.

    Returns: A numpy array of shape (n, 1) having distance between the given parallel lines.
    """

    # Create distance vector from pointOnLine1 to pointOnLine2
    distanceVector = directionVector(pointOnLine1, pointOnLine2)

    # Compute cross product between distanceVector and direction cosines of Line1
    crossProd = np.cross(distanceVector, line1DCs)

    # Compute the length by finding magnitude of the vector obtained from cross product.
    length = magnitude(crossProd)
    # Return the distance between the parallel lines.
    return length


def collinear(line1DCs: np.ndarray, line2DCs: np.ndarray, pointOnLine1: np.ndarray, pointOnLine2: np.ndarray):
    """
    Determines if two lines are co-axial
    Args:
        line1DCs: Numpy array of shape (n,3) or (n,2)
        line2DCs: Numpy array of shape (n,3) or (n,2)
        pointOnLine1: Numpy array of shape (n,3) or (n,2)
        pointOnLine2: Numpy array of shape (n,3) or (n,2)
    Returns: Boolean mask indicating collinearity
    """

    # todo:->varma sir clarify whether a line is in same dirn as other if any of the comps, return true.
    # todo:->varma sir eg: line1DCs: T F F, line2DCs: F F T
    # todo:->varma sir Is it possible to get an o/p such as T F T?

    # Check if line1DCs and line2DCs are in the same direction.
    line1_IsSameDirection_Line2 = isSameDirection(line1DCs, line2DCs)
    # Compute distance between parallel lines.
    distance = distanceBetween_ParallelLines(pointOnLine1, pointOnLine2, line1DCs)
    # Check if distance is under permissible tolerance.
    toleranceCheck_Distance = np.logical_and(distance <= 0, distance < 0.1)

    # Check if all conditions are satisfying to decide upon collinearity.
    isCollinear = np.logical_and(line1_IsSameDirection_Line2, toleranceCheck_Distance)
    # return an array indicating whether given lines are collinear.
    return isCollinear


# todo: NDY
def intersectionPoint_LineSegments(line1_Point1: np.ndarray, line1_point2: np.ndarray,
                                   line2_Point1: np.ndarray, line2_Point2: np.ndarray):
    """
    Computes intersection point between two lines
    Args:
        line1_Point1: numpy array of shape (n,3)
        line1_point2: numpy array of shape (n,3)
        line2_Point1: numpy array of shape (n,3)
        line2_Point2: numpy array of shape (n,3)
    Returns: Numpy array of shape (n,3) containing intersection point between the given lines wherever applicable.
    """
    return "Not Implemented Yet"


# todo: NDY
def projectedPointOfVertex_OnPlane(testPoint: np.ndarray, planeEquation: np.ndarray,
                                   projectionVector: np.ndarray):
    """
    Determines the co-ordinates of the projected point on the vertex.
    Args:
        testPoint: numpy array of shape (n,3)
        planeEquation: numpy array of shape (n,4)
        projectionVector: numpy array of shape (n,3)

    Returns: Co-ordinates of the projected point on the vertex.
    """
    return "Not Implemented Yet"
