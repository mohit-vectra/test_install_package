import os
import pandas as pd
import data_engine.correction.src.vct_lib.correct_dataframe as cdf
import json


def start(dataFrames, requiredColumns, columnDataTypes, dataPreferences, missingColumns):

    addMissingColumns = cdf.addMissingColumns(dataFrames, missingColumns)

    correctCasingAndDelimiters = cdf.correctCaseAndDelimiters(data=addMissingColumns,
                                                              case=dataPreferences['preferred_case'],
                                                              delimiter=dataPreferences['delimiter'])

    normalizedData = cdf.normalizeDataFrames(data=correctCasingAndDelimiters, requiredColumns=requiredColumns)

    # castToTypes = cdf.castColumnsToDataTypes(data=normalizedData, dataTypeDict=columnDataTypes)

    return normalizedData


if __name__ == '__main__':
    with open("./config/io_paths.json", "r") as paths:
        ioPaths = json.load(paths)

    with open("./config/io_files.json", "r") as files:
        ioFiles = json.load(files)

    inputDir = os.path.join(ioPaths['input'], ioFiles['input'])
    dataFramesDict = {}

    for csvFileName in os.listdir(inputDir):
        csvFilePath = os.path.join(inputDir, csvFileName)
        if 'json' in csvFilePath or 'Mating_Body_Info' in csvFilePath:
            continue
        # df = pd.read_csv(csvFilePath)
        df = pd.read_parquet(csvFilePath)
        dataFramesDict[((csvFileName.split('.')[0]).lower()).replace(" ", "_")] = df

    with open("./config/columns.json", "r") as json_file:
        requiredColumns = json.load(json_file)

    with open("./config/column_data_types.json", "r") as json_file:
        columnDataTypes = json.load(json_file)

    with open("./config/data_preferences.json", "r") as json_file:
        dataPreferences = json.load(json_file)

    with open("./config/missing_columns.json", "r") as json_file:
        missingColumns = json.load(json_file)

    correctedData = start(dataFramesDict, requiredColumns, columnDataTypes,
                          dataPreferences, missingColumns)

    for dfName, dfData in correctedData.items():
        partNameDir = os.path.join(ioPaths['output'], ioFiles['output'])
        if not os.path.exists(partNameDir):
            os.makedirs(partNameDir)
        # fileName = f"{dfName}.csv"
        fileName = f"{dfName}.parquet"
        outputFilePath = os.path.join(partNameDir, fileName)
        # dfData.to_csv(outputFilePath, index=False)
        dfData.to_parquet(outputFilePath, index=False)
