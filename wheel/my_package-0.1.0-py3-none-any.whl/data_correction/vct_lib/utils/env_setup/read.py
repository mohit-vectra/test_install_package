import json  # Import the json module for handling JSON data
import os  # Import the os module for interacting with the operating system


class Production:

    @classmethod
    def runtimeJSON(cls, file_path):
        # Construct the full path to the runtime.json file
        jsonFilePath = os.path.join(file_path, "runtime.json")

        # Open the runtime.json file and read its content
        with open(jsonFilePath, "r") as file:
            data = json.load(file)  # Load the JSON data from the file

        return data  # Return the loaded JSON data

    @classmethod
    def outputDirJSON(cls, file_path):
        # Construct the full path to the target_dir.json file
        jsonFilePath = os.path.join(file_path, "output_dir.json")

        # Open the target_dir.json file and read its content
        with open(jsonFilePath, "r") as file:
            data = json.load(file)  # Load the JSON data from the file

        return data  # Return the loaded JSON data

    @classmethod
    def packageDirPaths(cls, file_path):
        # Construct the full path to the dir_constants.json file
        jsonFilePath = os.path.join(file_path, "dir_constants.json")

        # Open the dir_constants.json file and read its content
        with open(jsonFilePath, "r") as file:
            data = json.load(file)  # Load the JSON data from the file

        return data  # Return the loaded JSON data

    @classmethod
    def packageFilePaths(cls, file_path):
        # Construct the full path to the file_constants.json file
        jsonFilePath = os.path.join(file_path, "file_constants.json")

        # Open the file_constants.json file and read its content
        with open(jsonFilePath, "r") as file:
            data = json.load(file)  # Load the JSON data from the file

        return data  # Return the loaded JSON data

    @classmethod
    def extractOutputDirPath(cls, runtime_json):
        # Construct the full path to the output directory config file
        filePath = os.path.join(runtime_json["OUTPUT_DIR_CONFIG_PATH"], runtime_json["OUTPUT_DIR_CONFIG_FILE"])

        # Open the output directory config file and read its content
        with open(filePath, "r") as file:
            outputPath = file.read().splitlines()  # Read lines and split into a list

        return outputPath[0]  # Return the first line as the output directory path

    @classmethod
    def toolPath(cls, output_dir):
        # Construct the full path to the Tool_Folder_Path.txt file
        toolPath = os.path.join(output_dir, "Config/Tool_Folder_Path.txt")

        # Open the Tool_Folder_Path.txt file and read its content
        with open(toolPath, "r") as file:
            outputPath = file.read().splitlines()  # Read lines and split into a list

        return outputPath[0]  # Return the first line as the tool path

    @classmethod
    def toolName(cls, tool_path):
        # Extract the tool name from the tool path by splitting on backslashes and getting the last element
        return tool_path.split("\\")[-1]

    @classmethod
    def programInputDir(cls, package_dir_paths, program_name):
        # Extract the tool name from the tool path by splitting on backslashes and getting the last element
        return package_dir_paths["program_io"][program_name]["input_dir"]

    @classmethod
    def programOutputDir(cls, package_dir_paths, program_name):
        # Extract the tool name from the tool path by splitting on backslashes and getting the last element
        return package_dir_paths["program_io"][program_name]["output_dir"]
